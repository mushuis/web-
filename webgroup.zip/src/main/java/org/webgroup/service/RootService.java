package org.webgroup.service;

import org.webgroup.entity.Root;

import java.util.List;

public interface RootService {
    public List<Root> selectRoot();
}
