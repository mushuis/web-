package org.webgroup.dao;

import org.webgroup.entity.Root;
import org.webgroup.entity.User;

import java.util.List;

public interface RootDao {
    List<Root> selectRoot();
}
